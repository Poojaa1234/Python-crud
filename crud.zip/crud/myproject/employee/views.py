from django.shortcuts import render, redirect, HttpResponseRedirect
from .forms import EmpForm
from .models import Employee


# Create your views here.

def home(request):
    return render(request, 'home.html')


def add(request):
    fm = EmpForm()
    return render(request, 'add.html',{'form':fm})

def show(request):
    if request.method == 'POST':
        fm = EmpForm(request.POST)
        if fm.is_valid():
            fm.save()
    else:
        fm = EmpForm()
    employee = Employee.objects.all()
    return render(request, 'show.html',{'form':fm,'emp':employee })

def delete_data(request,id):
    if request.method == 'POST':
        delrow= Employee.objects.get(pk=id)
        delrow.delete()
        return HttpResponseRedirect('/show')

def update_data(request,id):
    if request.method == 'POST':
        editrow = Employee.objects.get(pk=id)
        fm = EmpForm(request.POST, instance=editrow)
        if fm.is_valid():
            fm.save()
            return redirect('/show')
    else:
        editrow = Employee.objects.get(pk=id)
    fm = EmpForm(instance=editrow)
    return render(request,'edit.html', {'form': fm})
