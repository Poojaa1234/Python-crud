from django.db import models

# Create your models here.
class Employee(models.Model):
    Employee_Id     = models.CharField(max_length=20)
    Employee_Name   = models.CharField(max_length=100)
    Employee_Email = models.CharField(max_length=100)
    Employee_Contact = models.CharField(max_length=15)
    class Meta:
        db_table = "employee"
