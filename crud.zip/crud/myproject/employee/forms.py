from django import forms
from .models import Employee


class EmpForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = "__all__"
        widgets = {
            'Employee_Id': forms.TextInput(attrs={'class': 'form-control'}),
            'Employee_Name': forms.TextInput(attrs={'class': 'form-control'}),
            'Employee_Email': forms.EmailInput(attrs={'class': 'form-control'}),
            'Employee_Contact': forms.TextInput(attrs={'class': 'form-control'}),
        }